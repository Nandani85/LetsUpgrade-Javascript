let array=[1,2,3,4,5,6];
for (let index = array.length-1; index >=0; index--) {
    console.log(array[index]);
    
}