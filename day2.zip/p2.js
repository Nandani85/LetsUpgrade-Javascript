let min=2;
let sec;

console.log("minute is "+min);
sec=60*min;
console.log("second is "+sec);