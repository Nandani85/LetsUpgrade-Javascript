var array=["apple","boy","cat","dog","eye","fireball"];
let ch='a';
let flag=-1;
for(i=0;i<array.length;i++){
    for (let j = 0; j < array[i].length; j++) {
        if (ch==array[i][j]) {
            flag=i;        
        }       
    }
    if (flag==i) {
        console.log(array[i]);
    }

}