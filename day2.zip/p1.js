let str="confusion";
let ch='n';
let i=0;

while (i<str.length) {
    if (str[i]==ch) {
        console.log(ch+" is present at position "+i+" in "+str);
    }
    i++;
}
