var array=["apple","boy","cat","dog","eye","fire"];
let ele="cat";
let flag=0;
for (let i = 0; i < array.length; i++) {
    if(ele==array[i]){
        console.log(ele+" is present in array.");
        flag=1;
    }
    
}

if (flag==0) {
    console.log(ele+" is not present in array.");
}