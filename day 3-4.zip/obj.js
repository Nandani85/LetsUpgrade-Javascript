
//Question 3

let objs=[
        {
                name:"nobita",
                age:15,
                country:"japan",
                hobbies:["playing","eating"]

        },
        {
                name:"doremon",
                age:100,
                country:"japan-future",
                hobbies:["playing","scaring"]

        },
        {
                name:"sizuka",
                age:14,
                country:"india",
                hobbies:["playing","studying"]

        }



];

objs.forEach(function (element) {
        console.log(element);
});

//Question 4

objs.forEach(function (element) {
        if(element.age<30){
                console.log(element);
        }
});

objs.forEach(function (element) {
        if(element.country=="india"){
                console.log(element);
        }
});

